# BalatBlocks Offline Edition — بلاط

A fully offline Android puzzle arcade built with Android WebView, Java 17 and local HTML/CSS/JavaScript assets.

## What's included

### Main Balat Blocks game
- Classic endless mode and 30 adventure levels.
- 8×8 block-placement board, drag-and-drop, row/column clears, combos and score records.
- Undo, hints, gem objectives, local progress saving and six visual themes.
- Procedural sound effects and optional vibration.
- Arabic and English interface.

### More Games — eight playable offline mini-games
1. Tic Tac Toe — minimax computer opponent.
2. Fruit Merge — merge adjacent matching fruit tiles.
3. Water Sort — colour sorting across six tubes.
4. Mahjong Pairs — clear 18 matching tile pairs.
5. Sudoku — 9×9 number puzzle with validated entries.
6. One Line — trace a continuous path through all 16 nodes.
7. Onet — pair matching with a path finder allowing up to two turns.
8. Block Slide — move horizontal/vertical blocks to free the golden target.

Every game is implemented locally. No network permission is requested, remote fonts are removed, and the Android WebView blocks network loads. Scores, wins and arcade coins are stored on-device.

## Performance and lifecycle
- Reduced the block-trio solvability search budget to avoid long CPU spikes on mid-range phones.
- Removed unnecessary INTERNET permission and external font dependency.
- WebView is configured for local assets only and is destroyed when the Activity is destroyed.
- Honors Android back navigation between game, More Games and home screens.

## Build locally
Requirements: JDK 17, Android SDK Platform 34, Build Tools 34.0.0.

```bash
chmod +x ./gradlew
./gradlew --no-daemon clean assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Build on GitHub when the project ZIP itself is uploaded to repository root
Use the accompanying `BUILD-APK-WORKFLOW.yml` as the repository workflow at `.github/workflows/build-apk.yml`. It extracts any root ZIP file, locates `gradlew` inside the extracted folder, and builds the debug APK artifact.

If the project is uploaded already extracted to repository root, the same workflow also detects and builds it directly.

## Package
- Application ID: `com.balat.blocks`
- Version: `1.2.0` (versionCode 3)
- Minimum Android: 8.0 / API 26
- Target Android SDK: 34
- Offline: yes
